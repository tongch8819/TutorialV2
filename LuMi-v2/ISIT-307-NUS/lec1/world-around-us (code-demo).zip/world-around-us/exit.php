<?php
require_once __DIR__ . "/includes/lib.php";
require_game();

$nick = $_SESSION['nickname'];
$totalAllGames = get_total_score($nick);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Exit</title></head>
<body>
  <h2>Game Completed</h2>
  <p>Nickname: <strong><?=h($nick)?></strong></p>
  <p>Overall points (all games): <strong><?= $totalAllGames ?></strong></p>

  <p>
    <a href="restart.php">Start a new game</a>
  </p>
</body>
</html>
