<?php
session_start();
require_once __DIR__ . "/includes/lib.php";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nick = clean_nickname($_POST['nickname'] ?? '');
  if ($nick === '') {
    $error = "Please enter a nickname.";
  } else {
    $_SESSION['nickname'] = $nick;
    $_SESSION['session_points'] = 0; // overall points in CURRENT GAME (this session)
    header("Location: menu.php");
    exit;
  }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>The World Around Us</title></head>
<body>
  <h1>The World Around Us</h1>
  <p>Enter your nickname to start:</p>

  <?php if ($error): ?>
    <p style="color:red;"><?=h($error)?></p>
  <?php endif; ?>

  <form method="post">
    <input type="text" name="nickname" maxlength="20" required>
    <button type="submit">Start</button>
  </form>
</body>
</html>
