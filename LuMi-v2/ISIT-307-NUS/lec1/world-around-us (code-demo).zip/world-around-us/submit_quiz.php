<?php
require_once __DIR__ . "/includes/lib.php";
require_game();

$quiz = $_SESSION['current_quiz'] ?? null;
if (!$quiz || empty($quiz['topic']) || empty($quiz['items'])) {
  header("Location: menu.php");
  exit;
}

$topic = $quiz['topic'];
$items = $quiz['items'];

$correct = 0;
$incorrect = 0;

for ($i = 0; $i < 4; $i++) {
  $user = $_POST["a$i"] ?? '';
  $user = is_string($user) ? $user : '';
  $userNorm = normalize($user);

  $ans = $items[$i]['answer'];
  $ansNorm = normalize($ans);

  $isRight = false;

  if ($topic === 'animals') {
    // empty counts as incorrect by requirement
    if ($userNorm !== '' && $userNorm === $ansNorm) $isRight = true;
  } else {
    // Environment: radio not chosen => incorrect
    // answers stored as "T" or "F"
    if ($userNorm !== '' && ($userNorm === 't' || $userNorm === 'f')) {
      $isRight = (mb_strtoupper($userNorm) === mb_strtoupper($ansNorm));
    }
  }

  if ($isRight) $correct++;
  else $incorrect++;
}

$quizPoints = ($correct * 2) - ($incorrect * 1);

$_SESSION['last_result'] = [
  'topic' => $topic,
  'correct' => $correct,
  'incorrect' => $incorrect,
  'quiz_points' => $quizPoints
];

// update current game session points
$_SESSION['session_points'] = (int)($_SESSION['session_points'] ?? 0) + $quizPoints;

// update cumulative leaderboard (all games)
add_to_leaderboard($_SESSION['nickname'], $quizPoints);

// clear current quiz
unset($_SESSION['current_quiz']);

header("Location: result.php");
exit;
