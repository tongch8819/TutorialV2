<?php
require_once __DIR__ . "/includes/lib.php";
require_game();

$nick = $_SESSION['nickname'];
$sessionPts = (int)($_SESSION['session_points'] ?? 0);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Menu</title></head>
<body>
  <h2>Welcome, <?=h($nick)?>!</h2>
  <p>Current game points: <strong><?= $sessionPts ?></strong></p>

  <h3>Choose an option</h3>
  <ul>
    <li><a href="quiz.php?topic=animals">Animals Quiz</a></li>
    <li><a href="quiz.php?topic=environment">Environment Quiz</a></li>
    <li><a href="leaderboard.php">Leaderboard</a></li>
    <li><a href="exit.php">Exit</a></li>
  </ul>
</body>
</html>
