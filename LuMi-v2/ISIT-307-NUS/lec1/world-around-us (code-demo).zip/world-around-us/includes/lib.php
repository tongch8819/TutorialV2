<?php
declare(strict_types=1);

function h(string $s): string {
  return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function require_game(): void {
  session_start();
  if (empty($_SESSION['nickname'])) {
    header("Location: index.php");
    exit;
  }
}

function clean_nickname(string $name): string {
  $name = trim($name);
  // keep it kid-friendly: letters, numbers, spaces, underscore, dash (max 20)
  $name = preg_replace('/[^a-zA-Z0-9 _-]/', '', $name) ?? '';
  $name = trim($name);
  if (mb_strlen($name) > 20) $name = mb_substr($name, 0, 20);
  return $name;
}

function topic_file(string $topic): string {
  $topic = strtolower($topic);
  if ($topic === 'animals') return __DIR__ . '/../data/animals.txt';
  if ($topic === 'environment') return __DIR__ . '/../data/environment.txt';
  throw new RuntimeException("Invalid topic");
}

function load_questions(string $topic): array {
  $path = topic_file($topic);
  if (!file_exists($path)) return [];

  $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  $qs = [];
  foreach ($lines as $line) {
    $parts = explode('|', $line, 2);
    if (count($parts) !== 2) continue;
    $answer = trim($parts[0]);
    $prompt = trim($parts[1]);
    if ($answer === '' || $prompt === '') continue;

    $qs[] = [
      'answer' => $answer,
      'prompt' => $prompt
    ];
  }
  return $qs;
}

function pick_random_questions(array $questions, int $count = 4): array {
  shuffle($questions);
  return array_slice($questions, 0, $count);
}

function normalize(string $s): string {
  $s = trim(mb_strtolower($s));
  // collapse inner whitespace
  $s = preg_replace('/\s+/', ' ', $s) ?? $s;
  return $s;
}

// ---------- Leaderboard (text file JSON) ----------

function leaderboard_path(): string {
  return __DIR__ . '/../data/leaderboard.json';
}

function load_leaderboard(): array {
  $path = leaderboard_path();
  if (!file_exists($path)) return [];
  $raw = file_get_contents($path);
  $data = json_decode($raw ?: "{}", true);
  return is_array($data) ? $data : [];
}

function save_leaderboard(array $lb): void {
  $path = leaderboard_path();
  $json = json_encode($lb, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

  $fp = fopen($path, 'c+');
  if (!$fp) throw new RuntimeException("Cannot open leaderboard file");

  // lock for safe updates
  flock($fp, LOCK_EX);
  ftruncate($fp, 0);
  rewind($fp);
  fwrite($fp, $json ?: "{}");
  fflush($fp);
  flock($fp, LOCK_UN);
  fclose($fp);
}

function add_to_leaderboard(string $nickname, int $delta): void {
  $nickname = clean_nickname($nickname);
  if ($nickname === '') return;

  $lb = load_leaderboard();
  if (!isset($lb[$nickname])) $lb[$nickname] = 0;
  $lb[$nickname] = (int)$lb[$nickname] + $delta;
  save_leaderboard($lb);
}

function get_total_score(string $nickname): int {
  $lb = load_leaderboard();
  return isset($lb[$nickname]) ? (int)$lb[$nickname] : 0;
}
