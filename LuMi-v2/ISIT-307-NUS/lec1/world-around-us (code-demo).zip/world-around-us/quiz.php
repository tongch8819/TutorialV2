<?php
require_once __DIR__ . "/includes/lib.php";
require_game();

$topic = strtolower($_GET['topic'] ?? '');
if (!in_array($topic, ['animals', 'environment'], true)) {
  header("Location: menu.php");
  exit;
}

$all = load_questions($topic);
if (count($all) < 8) {
  die("Error: Topic '$topic' must have at least 8 questions in the text file.");
}

$quizItems = pick_random_questions($all, 4);

// store current quiz in session to prevent tampering
$_SESSION['current_quiz'] = [
  'topic' => $topic,
  'items' => $quizItems
];
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Quiz</title></head>
<body>
  <h2><?=h(ucfirst($topic))?> Quiz (4 questions)</h2>

  <form method="post" action="submit_quiz.php">
    <input type="hidden" name="topic" value="<?=h($topic)?>">

    <ol>
      <?php foreach ($quizItems as $i => $q): ?>
        <li style="margin-bottom:14px;">
          <p><?=h($q['prompt'])?></p>

          <?php if ($topic === 'animals'): ?>
            <input type="text" name="a<?= $i ?>" placeholder="Type the animal name">
          <?php else: ?>
            <label><input type="radio" name="a<?= $i ?>" value="T"> True</label>
            <label><input type="radio" name="a<?= $i ?>" value="F"> False</label>
          <?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ol>

    <button type="submit">Submit Quiz</button>
  </form>

  <p><a href="menu.php">Back to menu</a></p>
</body>
</html>
