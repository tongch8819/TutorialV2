<?php
require_once __DIR__ . "/includes/lib.php";
require_game();

$res = $_SESSION['last_result'] ?? null;
if (!$res) {
  header("Location: menu.php");
  exit;
}

$nick = $_SESSION['nickname'];
$sessionPts = (int)($_SESSION['session_points'] ?? 0);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Results</title></head>
<body>
  <h2>Quiz Results</h2>
  <p><strong>Topic:</strong> <?=h(ucfirst($res['topic']))?></p>

  <ul>
    <li>Correct: <strong><?= (int)$res['correct'] ?></strong></li>
    <li>Incorrect: <strong><?= (int)$res['incorrect'] ?></strong></li>
    <li>Points from this quiz: <strong><?= (int)$res['quiz_points'] ?></strong></li>
  </ul>

  <p><?=h($nick)?>’s current game points: <strong><?= $sessionPts ?></strong></p>

  <h3>What next?</h3>
  <ul>
    <li><a href="quiz.php?topic=animals">Start another Animals quiz</a></li>
    <li><a href="quiz.php?topic=environment">Start another Environment quiz</a></li>
    <li><a href="leaderboard.php">View Leaderboard</a></li>
    <li><a href="exit.php">Exit</a></li>
  </ul>
</body>
</html>
