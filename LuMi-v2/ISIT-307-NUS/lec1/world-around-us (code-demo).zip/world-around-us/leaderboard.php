<?php
require_once __DIR__ . "/includes/lib.php";
require_game();

$lb = load_leaderboard();
$sort = $_GET['sort'] ?? 'score'; // score | name

$rows = [];
foreach ($lb as $name => $score) {
  $rows[] = ['name' => $name, 'score' => (int)$score];
}

if ($sort === 'name') {
  usort($rows, fn($a,$b) => strcmp(mb_strtolower($a['name']), mb_strtolower($b['name'])));
} else {
  usort($rows, fn($a,$b) => $b['score'] <=> $a['score']);
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Leaderboard</title></head>
<body>
  <h2>Leaderboard (cumulative points)</h2>

  <p>
    Sort:
    <a href="leaderboard.php?sort=score">Greatest score</a> |
    <a href="leaderboard.php?sort=name">Nickname</a>
  </p>

  <?php if (empty($rows)): ?>
    <p>No scores yet.</p>
  <?php else: ?>
    <table border="1" cellpadding="6">
      <tr><th>Nickname</th><th>Points</th></tr>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?=h($r['name'])?></td>
          <td><?= (int)$r['score'] ?></td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>

  <p><a href="menu.php">Back to menu</a></p>
</body>
</html>
